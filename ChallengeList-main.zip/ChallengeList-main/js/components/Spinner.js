export default {
    template: `<p class="spinner">Loading...</p>`,
};
